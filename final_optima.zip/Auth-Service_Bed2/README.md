# Total Balance Service

## Getting Started

### Prerequisites

Git

JDK 8 or later

Maven 3.0 or later

## Clone

To get started you can simply clone this repository using git: 

git@github.com:immersive-induction/totalbalance-service.git

## Deployment

Run locally as Spring-Boot application in its own container

## Localhost URL : 
**For All Users** : localhost:8081/account/totalBalance

**For Specific User** : localhost:8081/account/user/totalBalance
