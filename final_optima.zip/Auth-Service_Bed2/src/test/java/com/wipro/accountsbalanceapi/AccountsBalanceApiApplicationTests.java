package com.wipro.accountsbalanceapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountsBalanceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
