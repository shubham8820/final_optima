package com.wipro.optima.auth.model;

import java.util.Arrays;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "credentials")
public class UserDetails {
	@Id
	private String _id;
	private Credentials[] userData;

	public UserDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserDetails(String _id, Credentials[] userData) {
		super();
		this._id = _id;
		this.userData = userData;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public Credentials[] getUserData() {
		return userData;
	}

	public void setUserData(Credentials[] userData) {
		this.userData = userData;
	}

	@Override
	public String toString() {
		return "UserDetail [_id=" + _id + ", userData=" + Arrays.toString(userData) + "]";
	}

}
