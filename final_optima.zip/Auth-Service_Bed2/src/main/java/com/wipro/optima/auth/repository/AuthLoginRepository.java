package com.wipro.optima.auth.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.wipro.optima.auth.model.UserDetails;

@Repository
public interface AuthLoginRepository extends MongoRepository<UserDetails, String> {

	@Query(value = "{userData:{$elemMatch:{username:?0}}}")
	UserDetails findByUserName(String username);

}
