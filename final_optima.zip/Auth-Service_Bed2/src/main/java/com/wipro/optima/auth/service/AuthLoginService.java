package com.wipro.optima.auth.service;

import java.util.List;

import com.wipro.optima.auth.model.Credentials;
import com.wipro.optima.auth.model.UserDetails;

public interface AuthLoginService {

	List<UserDetails> getTotalBalance();

	Credentials getTotalBalanceByUserName(String username,String password,String type) throws Exception;
}
