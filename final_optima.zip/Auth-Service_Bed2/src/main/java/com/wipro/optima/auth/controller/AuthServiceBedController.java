package com.wipro.optima.auth.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;

import com.wipro.optima.auth.controller.AuthenticationRequest;
import com.wipro.optima.auth.controller.AuthenticationResponse;
import com.wipro.optima.auth.model.Credentials;
import com.wipro.optima.auth.model.UserDetails;
import com.wipro.optima.auth.service.AuthLoginServiceImpl;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;


@RestController
@RequestMapping("/")
public class AuthServiceBedController {
	@Autowired
	AuthLoginServiceImpl service;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	AuthenticationResponse authenticationResponse;

	/*@GetMapping("/")
	public List<UserDetails> getTotalBalance() {
		return service.getTotalBalance();
	}*/

	/*@GetMapping("/auth/authService/login")
	public ResponseEntity<?> getTotalBalanceByUserName(@RequestParam(defaultValue = "empty") String userName, @RequestParam(defaultValue = "empty") String Password,@RequestParam(defaultValue = "empty") String type) throws Exception 
	{
		//authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userName,Password));	
		if(service.getTotalBalanceByUserName(userName,Password,type) == null)
			return ResponseEntity.ok(new AuthenticationResponse("LOGGED IN"));
		//return null;
		return ResponseEntity.ok(new AuthenticationResponse("UNABLE TO LOGIN"));
		
	}*/
	@PostMapping("/auth/authService/login")
	public AuthenticationResponse authenticateuser(@RequestParam(defaultValue = "empty") String userName, @RequestParam(defaultValue = "empty") String Password,@RequestParam(defaultValue = "empty") String type) throws Exception 
	{
		if(service.getTotalBalanceByUserName(userName,Password,type) == null)
		{
			authenticationResponse.setAuthenticated(true);
			authenticationResponse.setUserId(userName);
			authenticationResponse.setType(type);
			authenticationResponse.setToken("Authentication Successful");
			return authenticationResponse;
		}
		authenticationResponse.setAuthenticated(false);
		authenticationResponse.setUserId(userName);
		authenticationResponse.setType(type);
		authenticationResponse.setToken("Authentication Failed");
		return authenticationResponse;
		
	}

	
	/*public Credentials getTotalBalanceByUserName(@RequestHeader String userName,String Password) throws Exception 
	{
		return service.getTotalBalanceByUserName(userName,Password);
	}*/

}
