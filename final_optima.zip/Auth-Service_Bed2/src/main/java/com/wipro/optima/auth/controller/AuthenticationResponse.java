package com.wipro.optima.auth.controller;

import org.springframework.stereotype.Service;

@Service
public class AuthenticationResponse {

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public boolean getAuthenticated() {
		return authenticated;
	}

	public void setAuthenticated(boolean authenticated) {
		this.authenticated = authenticated;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	private String userId;
	private boolean authenticated;
	private String type;
	private String token;



}




/*public class AuthenticationResponse {
	private String response;
	public AuthenticationResponse()
	{
		
	}
	public AuthenticationResponse(String response) {
		this.response = response;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	
	
	

}*/