package com.wipro.optima.auth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.optima.auth.model.Credentials;
import com.wipro.optima.auth.model.UserDetails;
import com.wipro.optima.auth.repository.AuthLoginRepository;

@Service
public class AuthLoginServiceImpl implements AuthLoginService {
	@Autowired
	AuthLoginRepository repository;

	public List<UserDetails> getTotalBalance() 
	{
		List<UserDetails> userdetails = repository.findAll();
		System.out.println(userdetails.get(0).toString());
		//return repository.findAll();
		return userdetails;
	}

	public Credentials getTotalBalanceByUserName(String userName,String Password,String type) throws Exception {

		UserDetails userDetails = repository.findByUserName(userName);
		if (userDetails == null) {
			throw new Exception("ACCOUNT_NOT_FOUND");
		}
		for (Credentials user : userDetails.getUserData()) {
			if (user.getUsername().equals(userName))
			{
				if(!Password.equals(user.getPassword()))
				{
					//System.out.println("PASSWORD MATHCHED");
					throw new Exception("WRONG PASSWORD");
				}
				if(!type.equals(user.getType()))
				{
					//System.out.println("PASSWORD MATHCHED");
					throw new Exception("WRONG TYPE");
				}
				
				//SendResponse
				
				/*
				 * 
				 * redirect to(welcomepage.html)
				 * 
				 * 
				 * 
				 * */
				
				//System.out.println(user.getPassword());
				//System.out.println(user.getType());
				//System.out.println(Password);
				
				
				System.out.println("LOGIN ALLOWED");
				return null;
			}	
		}
		return null;
	}
}
