package com.wipro.optima.auth.exceptions;

public class ExceptionResponse {
	
	
	private String Status;
	private String error;
	private String message;
	public ExceptionResponse(String status, String error, String message) {
		super();
		Status = status;
		this.error = error;
		this.message = message;
	}
	public String getStatus() {
		return Status;
	}
	public String getError() {
		return error;
	}
	public String getMessage() {
		return message;
	}


}
